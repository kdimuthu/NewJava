package CucumberExamples.stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.assertEquals;


public class LoginTest {

    //initialize web-driver
    WebDriver driver;

    @Given("I have open a new browser")
    public void iHaveOpenANewBrowser() {

        //  System.setProperty("webdriver.chrome.driver", "/D:/SampleCodesNew/src/libs/chromedriver.exe");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        //Load the chromedriver
        driver=new ChromeDriver();
    }

    @When("I open the application")
    public void iOpenTheApplication() {
        //Navigates to URL
        driver.get("https://demo.guru99.com/test/newtours/");
        //maximize the browser
        driver.manage().window().maximize();
    }

    @Then("Should exit the title")
    public void shouldExitTheTitle() {
        driver.getTitle();
        assertEquals(driver.getTitle(), "Welcome: Mercury Tours");
    }

}
