package CucumberExamples.stepDefinition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

public class LoginWithoutScenarioOutline {

    WebDriver driver;

    @Given("I am on Home Page")
    public void iAmOnHomePage() {

        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver = new ChromeDriver();

    }

    @When("User Navigate to Login Page")
    public void userNavigateToLogInPage() {

        //Navigates to URL
        driver.get("https://demo.guru99.com/test/newtours/");
        //maximize the browser
        driver.manage().window().maximize();

    }

    @And("User enters {string} and {string} and Click Submit button")
    public void userEntersAndAndClickSubmitButton(String username, String password) {

        //Type username
        driver.findElement(By.name("userName")).sendKeys(username);
        //Type password
        driver.findElement(By.name("password")).sendKeys(password);
        //Click login button
        driver.findElement(By.name("submit")).click();
        //Wait
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

    }

    @Then("Message displayed Login Successfully")
    public void messageDisplayedLoginSuccessfully() {

        //Verify login success message is showing correctly
        String ActualLoginSuccessMessage = driver.findElement(By.xpath("//h3[text()='Login Successfully']")).getText();
        String ExpectedLoginSuccessMessage = "Login Successfully";
        Assert.assertEquals(ActualLoginSuccessMessage,ExpectedLoginSuccessMessage);
        driver.close();

    }
}
