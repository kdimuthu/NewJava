package CucumberExamples.stepDefinition;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class LoginWithDataTable {

    WebDriver driver;

    @Given("I am on Login Page")
    public void iAmOnLoginPage() {

        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver = new ChromeDriver();

    }

    @When("I Navigate to Login Page.")
    public void iNavigateToLoginPage() {

        //Navigates to URL
        driver.get("https://demo.guru99.com/test/newtours/");
        //maximize the browser
        driver.manage().window().maximize();

    }

    @And("I enters username and password and Click Submit button")
    public void iEntersUsernameAndPasswordAndClickSubmitButton(DataTable table) {
        //Initialize the data table
        List<String> loginForm = table.asList();
        //Type username
        driver.findElement(By.name("userName")).sendKeys(loginForm.get(0));
        //Type password
        driver.findElement(By.name("password")).sendKeys(loginForm.get(1));
        //Click login button
        driver.findElement(By.name("submit")).click();
        //Wait
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @Then("Success Message displayed Login Successfully.")
    public void successMessageDisplayedLoginSuccessfully() {
        //Verify login success message is showing correctly
        String ActualLoginSuccessMessage = driver.findElement(By.xpath("//h3[text()='Login Successfully']")).getText();
        String ExpectedLoginSuccessMessage = "Login Successfully";
        Assert.assertEquals(ActualLoginSuccessMessage,ExpectedLoginSuccessMessage);
        driver.close();
    }
}
