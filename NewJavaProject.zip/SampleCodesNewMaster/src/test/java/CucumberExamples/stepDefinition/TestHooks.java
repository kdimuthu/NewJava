package CucumberExamples.stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TestHooks {

    @Given("this is the first step")
    public void thisIsTheFirstStep() {
        System.out.println("This is first step");
    }

    @When("this is the second step")
    public void thisIsTheSecondStep() {
        System.out.println("This is second step");

    }

    @Then("this is the third step")
    public void thisIsTheThirdStep() {
        System.out.println("This is third step");
    }
}
