package CucumberExamples.runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

/*If you want to run multiple step definitions files , please find a way to run a way using runner class.
If you have only a single feature file & single step definitions , you can run your test by right-clicking runner class*/

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "Feature"
        ,glue={"CucumberExamples.stepDefinition"},
        //  ,dryRun = true
        monochrome = true
       ,plugin ={"pretty","html:target/Report"}
)
public class JUnitRunnerTest {
    
}
