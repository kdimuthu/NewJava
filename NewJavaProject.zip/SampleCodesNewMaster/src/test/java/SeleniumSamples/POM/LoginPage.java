package SeleniumSamples.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

     WebDriver driver;

    private By tf_UserName = By.xpath("//input[@name='userName']");
    private By tf_Password = By.xpath("//input[@name='password']");
    private By btn_Submit = By.xpath("//input[@name='submit']");

    public LoginPage(WebDriver driver) {

        this.driver = driver;
    }
    //This is how we do without parameterizing

    //Enter Username
    public void EnterUsername(){
        driver.findElement(tf_UserName).sendKeys("dimuthur");
    }

    //Enter Password
    public void EnterPassword(){
        driver.findElement(tf_Password).sendKeys("1qaz2wsx@");
    }

    //Click Submit button
    public void ClickSubmit(){
        driver.findElement(btn_Submit).click();
    }

    //This is how we do with parameterization

    //Enter Username
    public void EnterUsername(String username){
        driver.findElement(tf_UserName).sendKeys(username);
    }

    //Enter Password
    public void EnterPassword(String password){
        driver.findElement(tf_Password).sendKeys(password);
    }


}
