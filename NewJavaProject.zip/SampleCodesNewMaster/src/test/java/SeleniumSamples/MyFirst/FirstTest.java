package SeleniumSamples.MyFirst;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class FirstTest {
    public static void main(String[] args) {
        //initialize web-driver
        WebDriver driver;
        //  System.setProperty("webdriver.chrome.driver", "/D:/SampleCodesNew/src/libs/chromedriver.exe");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        //Load the chromedriver
        driver=new ChromeDriver();
        //Navigates to URL
        driver.get("https://demo.guru99.com/test/newtours/");
        //maximize the browser
        driver.manage().window().maximize();
        //Type username
        driver.findElement(By.name("userName")).sendKeys("dimuthur");
        //Type password
        driver.findElement(By.name("password")).sendKeys("1qaz2wsx@");
        //Click login button
        driver.findElement(By.name("submit")).click();
        String ActualLoginSuccessMessage = driver.findElement(By.xpath("//h3[text()='Login Successfully']")).getText();
        String ExpectedLoginSuccessMessage = "Login Successfully";
        if(ActualLoginSuccessMessage.equals(ExpectedLoginSuccessMessage)){
            System.out.println("Test Pass.Login Successfully to system and Success message is showing correctly as ");
        }
        else {
            System.out.println("Test Fail. Login Fail");
        }
        //Closing the browser
        driver.close();
    }
}
