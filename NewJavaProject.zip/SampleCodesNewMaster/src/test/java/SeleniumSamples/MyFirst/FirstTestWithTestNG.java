package SeleniumSamples.MyFirst;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class FirstTestWithTestNG {
    @Test
    public void login(){

        WebDriver driver;
        //  System.setProperty("webdriver.chrome.driver", "/D:/SampleCodesNew/src/libs/chromedriver.exe");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver = new ChromeDriver();
        //Navigates to URL
        driver.get("https://demo.guru99.com/test/newtours/");
        //maximize the browser
        driver.manage().window().maximize();
        //Type username
        driver.findElement(By.name("userName")).sendKeys("dimuthur");
        //Type password
        driver.findElement(By.name("password")).sendKeys("1qaz2wsx@");
        //Click login button
        driver.findElement(By.name("submit")).click();
        //Wait
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //Verify login success message is showing correctly
        String ActualLoginSuccessMessage = driver.findElement(By.xpath("//h3[text()='Login Successfully']")).getText();
        String ExpectedLoginSuccessMessage = "Login Successfully";
        Assert.assertEquals(ActualLoginSuccessMessage,ExpectedLoginSuccessMessage);
        driver.close();
    }
}
