package SeleniumSamples.POMWithPageFactory;

import SeleniumSamples.POM.HomePage;
import SeleniumSamples.POM.LoginPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginPage_Tests {

    WebDriver driver;

    SeleniumSamples.POM.LoginPage _LoginPage;
    SeleniumSamples.POM.HomePage _HomePage;

    @BeforeTest
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("http://demo.guru99.com/test/newtours/");
        driver.manage().window().maximize();
    }

     @Test
    public void ValidLogin() {
        _LoginPage=new LoginPage(driver);
        _LoginPage.EnterUsername("dimuthur");
        _LoginPage.EnterPassword("1qaz2wsx@");
        _LoginPage.ClickSubmit();
        _HomePage=new HomePage(driver);
        String message=_HomePage.GetLoginSuccessMessage();
        Assert.assertEquals(message,"Login Successfully");
    }
}
