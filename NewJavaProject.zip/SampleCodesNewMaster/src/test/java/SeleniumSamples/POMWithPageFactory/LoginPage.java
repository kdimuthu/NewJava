package SeleniumSamples.POMWithPageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;

public class LoginPage {
    WebDriver driver;
    /*This is the first way of locating elements.by specifying both 'How' and 'Using'*/
    @CacheLookup
    @FindBy(how = How.NAME,using = "userName")
    WebElement tf_UserName;
    /*/This is the second way of locating elements.Without using 'How' and 'Using'*/

    @CacheLookup
    @FindBy(xpath="//input[@name='password']")
    WebElement tf_Password;
    /*To locate a web element with more than one search criteria,
    you can use @FindBys annotation.
    This annotation locates the web element by using the AND condition on the search criteria.
    In simple words, @FindBys uses multiple @FindBy for each search criteria.
    */
    @CacheLookup
    @FindBys({
            @FindBy(name="submit"),
            @FindBy(tagName="input")
    })
    WebElement btn_Submit;
/*
    The @FindAll annotation locates the web element using more than a criteria, g
    iven that at least one criteria match. Contrary to @FindBys,
    it uses an OR conditional relationship between the multiple @FindBy.
 */

    @FindAll({
            @FindBy(xpath="//a[text()='REGISTER']"), //doesn't match
            @FindBy(tagName="a"), //Matches
    })
    WebElement btn_Register;

/* The @CacheLookUp annotation is very useful when you are referring to the same web element multiple times.
Consider an application where each test case requires Login operation.
In such a scenario, using @CacheLookUp,
we can store the web elements in cache memory right after reading for the first time.
It fastens our execution and the code,
need not look up for the element on the web page and directly references it from memory*/


    //Constructor, as every page needs a WebDriver to find elements
    public LoginPage(WebDriver driver){
        this.driver = driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }

    //This is how we do with parameterization

    //Enter Username
    public void EnterUsername(String username){

        tf_UserName.sendKeys(username);
    }

    //Enter Password
    public void EnterPassword(String password){

        tf_Password.sendKeys(password);
    }
    //Click Submit button
    public void ClickSubmit(){
        btn_Submit.click();
    }
}
