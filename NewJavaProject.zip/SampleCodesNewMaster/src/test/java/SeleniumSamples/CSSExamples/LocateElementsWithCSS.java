package SeleniumSamples.CSSExamples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class LocateElementsWithCSS {
    @Test
    public void DoCSS(){

        WebDriver driver;
        //  System.setProperty("webdriver.chrome.driver", "/D:/SampleCodesNew/src/libs/chromedriver.exe");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver = new ChromeDriver();
        //Navigates to URL
        driver.get("https://omayo.blogspot.com/");
        //maximize the browser
        driver.manage().window().maximize();

        /*Locate element using Tag and Attribute.
        Syntax is as follows
        css=<HTML tag>#<Value of ID attribute>
        */
        driver.findElement(By.cssSelector("textarea#ta1")).sendKeys("locating elements using tab and attribute");

        /*Locate element using Tag and Class.
        Syntax is as follows
        css=<HTML tag>.<Value of Class attribute>
        */
        String text=driver.findElement(By.cssSelector("h2.title")).getText();
        Assert.assertEquals(text,"Text Area Field");

         /*Locate element using Tag and Attribute.
        Syntax is as follows
        css=tag[attribute=value]
        */
        driver.findElement(By.cssSelector("textarea[id=ta1]")).clear();
        driver.findElement(By.cssSelector("textarea[id=ta1]")).sendKeys("Locating elements using tag and attribute");

          /*Locate element using Tag,Class and Attribute.
        Syntax is as follows
       css=tag.class[attribute=value]
        */

        driver.findElement(By.cssSelector("textarea.widget-content[id=ta1]")).clear();
        driver.findElement(By.cssSelector("textarea.widget-content[id=ta1]")).sendKeys("Locating elements using tag,class and attribute");

         /*Locate element using Inner Text.
        Syntax is as follows
       css=<HTML tag>:<contains><(text)>
        */
        String text3=driver.findElement(By.cssSelector("h2:contains(Text Area Field)")).getText();
        Assert.assertEquals(text3,"Text Area Field");
    }
}
