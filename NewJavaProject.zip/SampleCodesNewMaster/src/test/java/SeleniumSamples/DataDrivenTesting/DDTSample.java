package SeleniumSamples.DataDrivenTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DDTSample {

    @Test(dataProvider="testdata")
    public void doDataDrivenTesting(String username,String password) {

        WebDriver driver;
        //  System.setProperty("webdriver.chrome.driver", "/D:/SampleCodesNew/src/libs/chromedriver.exe");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver = new ChromeDriver();
        //Navigates to URL
        driver.get("https://demo.guru99.com/test/newtours/");
        //maximize the browser
        driver.manage().window().maximize();
        //Type username
        driver.findElement(By.name("userName")).sendKeys(username);
        //Type password
        driver.findElement(By.name("password")).sendKeys(password);
        //Click login button
        driver.findElement(By.name("submit")).click();

    }

    @DataProvider(name="testdata")
    public Object[][] TestDataFeed(){

  /* Create object array with 2 rows and 2 column
     first parameter is row and second is //column*/

        Object [][] loginData=new Object[2][2];
        // Enter data to row 0 column 0
        loginData[0][0]="dimuthur";
        // Enter data to row 0 column 1
        loginData[0][1]="1qaz2wsx@";
        // Enter data to row 1 column 0
        loginData[1][0]="dimuthuramachandra";
        // Enter data to row 1 column
        loginData[1][1]="1qaz2wsx@";
        // return array object to test script
        return loginData;
    }
}
