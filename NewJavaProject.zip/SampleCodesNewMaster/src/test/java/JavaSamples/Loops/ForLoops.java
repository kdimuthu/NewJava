package JavaSamples.Loops;

public class ForLoops {
}
