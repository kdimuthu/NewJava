package JavaSamples.Basics;

public class Casting {
    public static void main(String[] args) {
        //Widening Casting
        int a=230;
        double b=a;
        System.out.println("This is Widening Casting (automatically) "+ b);
        //Narrowing Casting
        double c=5.67;
        int d= (int) c;
        System.out.println("This is Narrowing Casting (automatically) "+ d);

        boolean e=true;

    }
}
