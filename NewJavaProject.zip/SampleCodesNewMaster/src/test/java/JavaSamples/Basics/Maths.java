package JavaSamples.Basics;

import com.mongodb.DBPortPool;

public class Maths {
    public static void main(String[] args) {
        int x=10,y=7,z=-8;
        double a=9.12;
        System.out.println("The maximum value is "+ Math.max(x,y));
        System.out.println("The minimum value is "+ Math.min(x,y));
        System.out.println("The square root is "+ Math.sqrt(x));
        System.out.println("The absolute value is "+ Math.abs(z));
        System.out.println("Random values from 1 to 10 "+ Math.random());
        System.out.println("Rounded values are "+ Math.round(a));
    }
}
