package JavaSamples.Exceptions;

public class ExceptionOne {
}
