package JavaSamples.ArrayList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Test {
    public static void main(String[] args) {
        ArrayList<String> al=new ArrayList<>();
        HashMap<String,Integer> hm=new HashMap();
        HashSet<Integer> hs=new HashSet<>();



    }
}
