package JavaSamples.Polymorphisam;

public class Cat extends Animal{
    public void animalSound() {
        System.out.println("The cat says: naw naw");
    }
}
