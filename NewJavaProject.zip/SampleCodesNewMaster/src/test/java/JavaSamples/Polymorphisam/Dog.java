package JavaSamples.Polymorphisam;

public class Dog extends Animal{
    public void animalSound() {
        System.out.println("The don says: bow bow");
    }
}
