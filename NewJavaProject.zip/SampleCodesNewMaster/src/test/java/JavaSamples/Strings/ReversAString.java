package JavaSamples.Strings;

public class ReversAString {
    public static void main(String[] args) {
        StringBuffer a = new StringBuffer("Java programming is fun");
        System.out.println(a.reverse());
    }
}
