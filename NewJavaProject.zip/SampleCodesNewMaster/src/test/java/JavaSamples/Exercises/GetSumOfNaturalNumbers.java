package JavaSamples.Exercises;

public class GetSumOfNaturalNumbers {
    public static void main(String[] args) {
        int number=10,i,sum=0;
        for(i=0;i<=number;i++){
            sum=sum+i;
        }
        System.out.println("Sum is :"+sum);
    }
}
