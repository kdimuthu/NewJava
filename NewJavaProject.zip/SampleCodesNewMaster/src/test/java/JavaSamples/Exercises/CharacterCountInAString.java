package JavaSamples.Exercises;

public class CharacterCountInAString {
    public static void main(String[] args) {
        String world="dimuthu";
        System.out.println("character count is " +world.length());
    }
}
