package JavaSamples.Exercises;

import java.util.HashMap;

public class FindCharacterCountForEachLetterInAWord {
    public static void main(String[] args) {
        /*String sentence="This is to find the character count a string";
        for (int i=0;i<sentence.length();i++){
            char character=sentence.charAt(i);
            HashMap<Character,Integer> characterCount=new HashMap<Character, Integer>();
            characterCount.put(character,1)
        }*/

        String str = "dimuthu";
        //HashMap char as a key and occurrence as a value
        HashMap <Character, Integer> charCount = new HashMap<>();
        for (int i = str.length() - 1; i >= 0; i--)
        {
            if(charCount.containsKey(str.charAt(i)))
            {
                int count = charCount.get(str.charAt(i));
                charCount.put(str.charAt(i), ++count);
            }
            else
            {
                charCount.put(str.charAt(i),1);
            }
        }
        System.out.println(charCount);
    }
}

