package JavaSamples.Exercises;

public class CheckWhetherNumberIsPositiveOrNegative {
    public static void main(String[] args) {
        double givenNumber=13.0;
        if(givenNumber>0){
            System.out.println("Given Number is a positive number: "+givenNumber);
        }

        else if(givenNumber<0){
            System.out.println("Given Number is a negative number: "+givenNumber);
        }

        else {
            System.out.println("Given number is 0 : "+givenNumber);
        }
    }
}
