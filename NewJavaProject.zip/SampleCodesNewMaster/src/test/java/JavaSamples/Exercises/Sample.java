package JavaSamples.Exercises;

import com.mongodb.DBPortPool;
import org.w3c.dom.ls.LSOutput;

public class Sample {
    public static void main(String[] args) {
        System.out.println("Helow Java");
    }
    
}
