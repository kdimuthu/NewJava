package JavaSamples.Exercises;

public class MultiplyTwoFloating {
    public static void main(String[] args) {
        float a=4,b=6;
        System.out.println("Multiplication of two number are "+ a*b);

    }
}
