package JavaSamples.Exercises;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class CharacterCountInAWord {
    public static void main(String[] args) {
        String word="Hello Java";
        int numberOfCharacters=0;
        for(int i=0;i<word.length();i++){
            char characters=word.charAt(i);
            if(characters=='H'){
                numberOfCharacters++;
            }
        }
        System.out.println("Number of characters for given letters are "+numberOfCharacters);
    }
}

