package JavaSamples.Inheritance;

public class Employee {
    float salary=40000;
}
