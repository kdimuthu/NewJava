package JavaSamples.Arrays;

public class Sample2D {
    public static void main(String[] args) {
        int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
        int x = myNumbers[1][1];
        System.out.println(x);

        System.out.println("This is 2D array printing");
        int[][] myNumbers2 = { {1, 2, 3, 4}, {5, 6, 7} };
        for (int i = 0; i < myNumbers2.length; ++i) {
            for(int j = 0; j < myNumbers2[i].length; ++j) {
                System.out.println(myNumbers2[i][j]);
            }
    }
}}
