package JavaSamples.Arrays;

public class Arrays {
    public static void main(String[] args) {
        int[] age={8,98,3,42};
        System.out.println("First element of integer array is "+age[0]);
        System.out.println("Array size is "+age.length);
        String[] name={"Dimuthu","Kenath","Ramachandra"};
        System.out.println("Last element of String array is "+name[2]);
        //Changing array elements
        name[1]="Sanul";
        System.out.println("Change array element is "+name[1]);
        //loop through array
        for (String i : name ) {
            System.out.println("Element is "+i);
        }
    }
}
