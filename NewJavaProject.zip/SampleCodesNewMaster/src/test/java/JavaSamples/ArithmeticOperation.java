package JavaSamples;

public class ArithmeticOperation {
    public static void main(String[] args) {

        // declare variables
        int a = 13, b = 5;

        // addition operator
        System.out.println("a + b = " + (a + b));

        // subtraction operator
        System.out.println("a - b = " + (a - b));

        // multiplication operator
        System.out.println("a * b = " + (a * b));

        // division operator
        System.out.println("a / b = " + (a / b));

        // modulo operator-This is get the remainder after division
        System.out.println("a % b = " + (a % b));
    }

}
