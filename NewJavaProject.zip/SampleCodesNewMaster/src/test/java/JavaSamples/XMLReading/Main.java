package JavaSamples.XMLReading;

public class Main {
    public static void main(String[] args) {

        ReadData objMethodTypes=new ReadData();
        objMethodTypes.newAdd();
    }
}
