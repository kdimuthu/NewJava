package JUnitSamples;

public class SampleOne {
    //New
}
