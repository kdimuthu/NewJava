package TestNGSampels;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ParallelExecutionSupport {

    WebDriver driver;

    @Test
    public void test5(){
        System.out.println("This is test 4");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("https://www.browserstack.com/");
        driver.manage().window().maximize();
    }

    @Test
    public void test6(){
        System.out.println("This is test 4");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("https://mail.google.com/");
        driver.manage().window().maximize();
    }
}
