package TestNGSampels;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ParallelExecution {

    WebDriver driver;

    @Test
    public void test1(){

        System.out.println("This is test 1");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("http://demo.guru99.com/test/newtours/");
        driver.manage().window().maximize();
    }

    @Test
    public void test2(){
        System.out.println("This is test 2");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("https://www.facebook.com/");
        driver.manage().window().maximize();
    }

    @Test
    public void test3(){
        System.out.println("This is test 3");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("https://www.linkedin.com/feed/");
        driver.manage().window().maximize();
    }

    @Test
    public void test4(){
        System.out.println("This is test 4");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("https://stackoverflow.com/");
        driver.manage().window().maximize();
    }

    @Test
    public void test5(){
        System.out.println("This is test 4");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("https://www.browserstack.com/");
        driver.manage().window().maximize();
    }

    @Test
    public void test6(){
        System.out.println("This is test 4");
        System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("https://mail.google.com/");
        driver.manage().window().maximize();
    }
}
