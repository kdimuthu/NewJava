package TestNGSampels;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserTest {

    WebDriver driver;

    @Test
    @Parameters("browser")
    public void parameterizedTest(String browser){
        System.out.println("parameterizedTest");
        if(browser.equalsIgnoreCase("firefox")){
            System.out.println("Open Firefox browser");
            System.setProperty("webdriver.gecko.driver", "./src/libs/geckodriver.exe");
            driver = new FirefoxDriver();

        }else if(browser.equalsIgnoreCase("chrome")){
            System.out.println("Open Chrome browser");
            System.setProperty("webdriver.chrome.driver", "./src/libs/chromedriver.exe");
            driver = new ChromeDriver();

        }else if(browser.equalsIgnoreCase("edge")){
            System.out.println("Open edge browser");
            System.setProperty("webdriver.edge.driver", "./src/libs/msedgedriver.exe");
            driver = new EdgeDriver();
        }
        driver.get("https://demo.guru99.com/test/newtours/");
        driver.close();
    }
}
